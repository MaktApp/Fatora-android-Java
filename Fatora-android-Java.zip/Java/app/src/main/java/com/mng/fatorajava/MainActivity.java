package com.mng.fatorajava;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button pay = findViewById(R.id.pay);
        pay.setOnClickListener(view -> {
            generatePaymentButton();

        });

    }

    private void generatePaymentButton() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    generatePayment();
                } catch (Exception exception) {
                    Log.e("Exception", exception.toString());
                }
            }
        });
        thread.start();
    }

    private void generatePayment() throws Exception {
        // URL of the endpoint we're going to contact (MAKTAPP CLOUD SOLUTIONS credit endpoint.
        URL url = new URL("https://maktapp.credit/v3/AddTransaction");

        // Create a POST request with our JSON as a request body.
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestProperty("Accept", "application/json");
        con.setDoOutput(true);

        // Create a simple dictionary with numbers.
        String dataIn = new JSONObject(getDataInPut()).toString();
        try (OutputStream os = con.getOutputStream()) {
            byte[] input = dataIn.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }

            //if code is 200 so the request return success so the response came back with data object that contain result value this have payment url link
            if (con.getResponseCode() == 200) {
                JSONObject result = new JSONObject(String.valueOf(response));
                String urlPayement = (String) result.get("result");
                Intent intent = new Intent(MainActivity.this, WebActivity.class);
                intent.putExtra("URL", urlPayement);
                startActivity(intent);
            }
        }


    }


    private HashMap<String, String> getDataInPut() {
        HashMap<String, String> dataIn = new HashMap<String, String>();
        dataIn.put("token", "E4B73FEE-F492-4607-A38D-852B0EBC91C9");//put here your account token
        dataIn.put("currencyCode", "QAR"); //put here your currency code
        dataIn.put("orderId", "100");//put here your order id
        dataIn.put("Note", ""); //put here your notes
        dataIn.put("customerName", "demo");//put here your customer name
        dataIn.put("customeremail", "demo@fatora.io");//put here your customer email
        dataIn.put("customerPhone", "");//put here your customer phone
        dataIn.put("isrecurring", "");//if your payment is recurring so you need to put (1) else (0)
        dataIn.put("customerCountry", "Qatar");//put here your customer country
        dataIn.put("Lang", "en"); //put here your language (en or ar)
        dataIn.put("Amount", "50");// put here your amount
        dataIn.put("from", "0");// put here from attributes value
        return dataIn;
    }
}